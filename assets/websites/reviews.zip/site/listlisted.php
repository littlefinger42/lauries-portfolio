<?php
if ( $num == 0 ) { //if no results
	echo "<h1>End of results</h1>"; //display message saying end of results
} else { //if there are results
	for ( $n = 0; $n <= $num-1; $n++ ) { //loop 1 to number of results
		//start defining local variables
		$filmimage = mysql_result($result,$n,"FilmPictureLocation");
		$filmname = mysql_result($result,$n,"FilmName");
		$filmid = mysql_result($result, $n, "FilmID");
		$filmnameadapted = "$filmname;";
		//finish defining local variables
		if ( strlen($filmnameadapted) > 25 ) { //if length of string is bigger than 25 characters...
			$position=25; // Characters allowed in $filmname
			$filmnameadapted = substr($filmname, 0, $position); //shrink string to characters allowed
			$filmnameadapted = "$filmnameadapted..."; //add "..."
		}
		echo "<li><a href = 'movie.php?id=$filmid'><img src=$filmimage alt='$filmname' title='$filmname' width=200 height=300><br>$filmnameadapted</a></li>";//display movie poster and shortened (if needed) name
	}
}
unset($_SESSION['num']); //clear session variable "num" for later use
?>