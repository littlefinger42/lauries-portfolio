<?php
Session_start(); //Starts PHP session
$_SESSION['whatpage'] = "films"; //Storing what page currently on (for navbar highlighting)

//start filling local variables
$display=$_GET['display'];// 1 = justadded 2 = featured 3 = popular
$pagenm=$_GET['page']; //page number
$searchvalue=$_GET['searchvalue']; //search value
$genre=$_GET['genre']; //genre search
$year=$_GET['year']; //year search
$num = 0;
//end filling local variables
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"> <!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title> <!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /> <!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" />  <!--Logo image itself with width and height definers-->
		<center>
	</div><!-- End Logo Container -->

	<div id="menu"><!-- Start Navigation Bar Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Navigation Bar Container -->
	
	<?php
	$whereami = $pagenm * 20; //works out where to start pulling movies from database (indicated by what page number on)
	
	if ( $searchvalue != '' ) { //if search value exists
		$searchvaluesearch = "WHERE FilmName LIKE '%$searchvalue%'"; //add search value aspect to query
	} else { //if search value doesnt exist
		$searchvaluesearch = ''; //dont add search value aspect to query
	}
	
	if ( $genre != '' ) { //if genre search exists
		if ( $searchvalue != '' ) { //and search value exists
			$genresearch = " AND (FilmGenre = '$genre' OR FilmGenreSecondary = '$genre')"; //add genre search to query, with ability to work with search value
		} else { //and search value doesnt exist
			$genresearch = "WHERE (FilmGenre = '$genre' OR FilmGenreSecondary = '$genre')"; //add genre search to query, with ability to work without search value
		}
	} else { //if genre search doesnt exist
		$genresearch = ''; //dont add genre search to query
	}
	
	if ( $year != '' ) { //if year search exists
		if ( $genre != '' ) { //and genre search exists
			$yearsearch = " AND FilmYear=$year"; //add year search to query, with ability to work with genre search
		} else { //if genre search doesnt exist
			$genresearch = "WHERE FilmYear=$year"; //add year search to query, without ability to work with genre search
		}
	} else { //if year search doesnt exist
		$yearsearch = ""; //dont add year search to query
	}
	
	if ( $searchvalue != '' ) { //if search value exists
		echo "<h2>Keyword: $searchvalue</h2>"; //Notify user that search value has been used and what value they used
	}
	if ( $genre != '' ) { //if genre search exists
		echo "<h2>Genre: $genre</h2>"; //notify user that genre search has been used and what genre they selected
	}
	if ( $year != '' ) { //if year search exists
		echo "<h2>Year: $year</h2>"; //notify user that year search has been used and what year they selected
	}
	
	require_once( "config.php" ); //grab config file and do whats in there
	mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
	@mysql_select_db($db_database); //connect to specific database
	$query = "SELECT * FROM tblfilms $searchvaluesearch$genresearch$yearsearch ORDER BY FilmName LIMIT $whereami,20 "; //Defining query
	$result = mysql_query($query); //Running query and filling result with query's results
	$num = mysql_numrows($result); //counts number of records found from query
	mysql_close(); //close MySQL connection

	if ( $display == 1 ) { //if user has clicked "Just Added"
		echo "<h2>Just Added:</h2>"; //notify user that they have selected "Just Added"
		require_once( "config.php" ); //grab config file and do whats in there
		mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
		@mysql_select_db($db_database); //connect to specific database
		$query = "SELECT * FROM tblfilms ORDER BY FilmTimeAdded DESC LIMIT $whereami,20"; //Defining query
		$result = mysql_query($query); //Running query and filling result with query's results
		$num = mysql_numrows($result); //counts number of records found from query
		mysql_close(); //Close MySQL connection
		
	} elseif ( $display == 2 ) { //if user has clicked "Featured"
		echo "<h2>Featured:</h2>"; //notify user that they have selected "Featured"
		require_once( "config.php" ); //grab config file and do whats in there
		mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
		@mysql_select_db($db_database); //connect to specific database
		$query = "SELECT * FROM tblfilms WHERE FilmFeatured=1 ORDER BY FilmTimeAdded DESC LIMIT $whereami,20"; //Defining query
		$result = mysql_query($query); //Running query and filling result with query's results
		$num = mysql_numrows($result); //counts number of records found from query
		mysql_close(); //close MySQL connection

	} elseif ( $display == 3 ) { //if user has clicked "Popular"
		echo "<h2>Popular:</h2>"; //notify user that they have selected "Popular"
		require_once( "config.php" ); //grab config file and do whats in there
		mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
		@mysql_select_db($db_database); //connect to specific database
		$query = "SELECT * FROM tblfilms ORDER BY FilmPopularity DESC LIMIT $whereami,20"; //Defining query
		$result = mysql_query($query); //Running query and filling result with query's results
		$num = mysql_numrows($result); //counts number of records found from query
		mysql_close(); //close MySQL connection
	}
	?>
	
	<div id="nextprev"><!-- Start Next Prev container -->
		<?php
			$nextpagenm = $pagenm + 1; //define next page
			$prevpagenm = $pagenm - 1; //define previous page
			
			if ( $pagenm == 0 && $num < 20 ) { //if on first page and results is less than 20
			//dont display next prev
			} elseif ( $pagenm > 0 ) { //else if not on page 1
				if ( $num < 20 ) { //and number of results is less than 20
					echo "<a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$prevpagenm'>Prev</a>";//display previous link
				} else { //or if number of results is more than 20
					echo "<a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$prevpagenm'>Prev</a>  -  <a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$nextpagenm'>Next</a>";//display next and previous links
				}
			} else { //else if not on page 1 and results more than 20
				echo "<a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$nextpagenm'>Next</a>"; //show next link
			}
		?>
	</div><!-- End Next Prev container -->
	
	<div id="listed"><!-- Start listed container -->
		<center>
			<?php
				require_once( "listlisted.php" );//link to listlisted.php and do whats in there (list the listings graphically)
			?>
		</center>
	</div><!-- End listed container -->
	
	<div id="nextprev"><!-- Start Next Prev container -->
		<?php
			$nextpagenm = $pagenm + 1; //define next page
			$prevpagenm = $pagenm - 1; //define previous page
			
			if ( $pagenm == 0 && $num < 20 ) { //if on first page and results is less than 20
			//dont display next prev
			} elseif ( $pagenm > 0 ) { //else if not on page 1
				if ( $num < 20 ) { //and number of results is less than 20
					echo "<a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$prevpagenm'>Prev</a>";//display previous link
				} else { //or if number of results is more than 20
					echo "<a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$prevpagenm'>Prev</a>  -  <a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$nextpagenm'>Next</a>";//display next and previous links
				}
			} else { //else if not on page 1 and results more than 20
				echo "<a href='listed.php?display=$display&searchvalue=$searchvalue&genre=$genre&year=$year&page=$nextpagenm'>Next</a>"; //show next link
			}
		?>
	</div><!-- End Next Prev container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to footer.php and do whats in there (display footer)
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->

</body>

</html>