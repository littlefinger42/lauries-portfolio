<?
$db_host="localhost"; //database host
$db_user="laurie"; //database username login
$db_password="123456"; //database password
$db_database="laurie"; //the name of the database
?>