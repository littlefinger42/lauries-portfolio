<?php
Session_start(); //Starting PHP session
$_SESSION['whatpage'] = "home"; //Storing what page currently on (for navbar highlighting)
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"><!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title><!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /><!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" /><!--Logo image itself with width and height definers-->
		</center>
	</div><!-- End Logo Container -->
	
	<div id="menu"><!-- Start Navigation Bar Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Navigation Bar Container -->
	
	<div id="featured"><!-- Start Featured Container -->
		<ul>
			<?php
				require_once( "listfeatured.php" ); //link to the feature listing display code. This is located in the listfeatured.php
			?>
		</ul>
	</div><!-- End Featured Container -->
	
	<div id="content"><!-- Start Content Container -->
		<h1>
		News <!--News header-->
		</h1>
		<?php
			require_once( "config.php" ); //grab database configuration file and configure settings
			mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
			@mysql_select_db($db_database); //connect to specific database
			$query = "SELECT * FROM tblnews ORDER BY NewsDate DESC LIMIT 0,3"; //defines query
			$result = mysql_query($query); //run query and fill result with query's results.
			mysql_close(); //close database connections
			for ( $i = 0; $i <= 2; $i++ ) { //loop 3 times to display the 3 different new items
				//Start Filling Local Variables with mysql result
				$newsname = mysql_result($result,$i,"NewsName");
				$newsnews = mysql_result($result,$i,"NewsNews");
				$newsdate = mysql_result($result,$i,"NewsDate");
				//End filling location variables with mysql result
				//Start displaying news
				echo "<h2>$newsname</h2>"; 
				echo "<p>$newsnews</p>";
				echo "<h3>$newsdate</h3>"; 
				//End displaying news items
			}
		?>
	</div><!-- End content container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to the footer display code. This is located in footer.php
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->
	
</body>

</html>