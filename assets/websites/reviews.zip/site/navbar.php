<?php
//begin filling local variables
$whatpage = $_SESSION['whatpage'];
$username = $_SESSION['username'];
//end filling local variables

if ($_SESSION['loggedin'] == 1) { //if user is logged in...
	$loginorprofile = "Profile"; //display link as "profile"
} else {
	$loginorprofile = "Login"; //or if not logged in, display link as "login"
}

if ( $whatpage == "home" ) { //if current page is home
	echo "<li class='current_page_item'><a href='index.php'>Home</a></li>";
	echo "<li><a href='search.php'>Films</a></li>";
	echo "<li><a href='dailytribune.html' target='_blank'>The Daily Tribune</a></li>";
	echo "<li><a href='profile.php'>$loginorprofile</a></li>";
	if ( $username == "admin" ) { //if user is admin, display admin CP code
	echo "<li><a href='admin.php'>AdminCP</a></li>";
	}
} elseif ( $whatpage == "films" ) {//if current page is films
	echo "<li><a href='index.php'>Home</a></li>";
	echo "<li class='current_page_item'><a href='search.php'>Films</a></li>";
	echo "<li><a href='dailytribune.html' target='_blank'>The Daily Tribune</a></li>";
	echo "<li><a href='profile.php'>$loginorprofile</a></li>";
	if ( $username == "admin" ) { //if user is admin, display admin CP code
	echo "<li><a href='admin.php'>AdminCP</a></li>";
	}
} elseif ( $whatpage == "login" ) {//if current page is login
	echo "<li><a href='index.php'>Home</a></li>";
	echo "<li><a href='search.php'>Films</a></li>";
	echo "<li><a href='dailytribune.html' target='_blank'>The Daily Tribune</a></li>";
	echo "<li class='current_page_item'><a href='profile.php'>$loginorprofile</a></li>";
	if ( $username == "admin" ) { //if user is admin, display admin CP code
	echo "<li><a href='admin.php'>AdminCP</a></li>";
	}
} elseif ( $whatpage == "admin" ) {//if current page is admin
	echo "<li><a href='index.php'>Home</a></li>";
	echo "<li><a href='search.php'>Films</a></li>";
	echo "<li><a href='dailytribune.html' target='_blank'>The Daily Tribune</a></li>";
	echo "<li><a href='profile.php'>$loginorprofile</a></li>";
	if ( $username == "admin" ) { //if user is admin, display admin CP code
	echo "<li class='current_page_item'><a href='admin.php'>Admin-CP</a></li>";
	}
}
	
?>