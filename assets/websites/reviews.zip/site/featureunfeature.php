<?
if(isset($_POST['submit'])) { //if submit button is clicked then...

	//start filling local variables
	$featured = $_SESSION['featured'];
	$filmid = $_SESSION['id'];
	//end filling local variables
	
	require_once( "config.php" ); //grab config file and do whats in there
	mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
	@mysql_select_db($db_database); //connect to specific database
	$query = "UPDATE tblfilms SET FilmFeatured='$featured' WHERE FilmID='$id'"; //Define query
	$result = mysql_query($query); //Run query and fill result with query's result
	mysql_close(); //close MySQL connection
	echo "<meta http-equiv='refresh' content='0;movie.php?id=$filmid'>"; //redirect user back to movie.php page
}
?>