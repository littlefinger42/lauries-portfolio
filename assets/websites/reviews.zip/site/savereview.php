<?php
require_once "formvalidator.php";//do whats in here

if(isset($_POST['submit'])) {//if submit button has been clicked
	//Setup Validations
	$validator = new FormValidator();
	$validator->addValidation("review","minlen=150","Review must be at least 150 characters long.");
	//Now, validate the form
	
	//begin declaring local variables
	$review = $_POST['review'];
	$userid = $_SESSION['userid'];
	$filmid = $_SESSION['id'];
	//end declaring local variables
	
	require_once( "config.php" ); //grab config file and do whats in there
	mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
	@mysql_select_db($db_database); //connect to specific database
	$query = "SELECT * FROM tblreviews WHERE UserID='$userid'"; //Defining Query
	$result = mysql_query($query); //Run query and fill result
	$num = mysql_numrows($result); //Count records in result
	mysql_close(); //Close MySQL query
	
	if ( $num > 0 ) { //If author has already authored a review
		echo "Review by this author exists already";
	} else { //if author hasnt authored a review
		if($validator->ValidateForm()) {
			//Validation success. 
			require_once( "config.php" ); //grab config file and do whats in there
			mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
			@mysql_select_db($db_database); //connect to specific database
			$query = "INSERT INTO tblreviews (UserID, FilmID, ReviewReview) VALUES ('$userid', '$filmid', '$review')"; //defining query
			$result = mysql_query($query); //Run query and fill result
			mysql_close(); //Close MySQL query
			echo "<h2>Review Added</h2>"; //Notify user that review has been added
		} else {
			//Unsucsessful validation
			echo "<B>Validation Errors:</B>";
			//Start Clearing Post Variables
			$_POST['FullName'] == "";
			$_POST['Email'] == "";
			$_POST['Username'] == "";
			$_POST['Password'] == "";
			$_POST['ConfirmPassword'] == "";
			//Finish Clearing Post Variables
			$error_hash = $validator->GetErrors();
			foreach($error_hash as $inpname => $inp_err)
			{
				echo "<p>$inp_err</p>\n";
			}        
		}
	}
}
?>
