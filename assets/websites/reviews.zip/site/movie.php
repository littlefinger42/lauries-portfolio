<?php
Session_start(); //starting PHP session
$_SESSION['whatpage'] = "films"; //Storing what page currently on (for navbar highlighting)
$id = $_GET['id']; //get ID of film viewing
$pagenm = $_GET['page']; //get page number currently on of reviews
$_SESSION['id'] = $id; //store id of film in session
$username = $_SESSION['username']; //get username of account logged on

//start grabbing movie info from database
require_once( "config.php" ); //grab config file and do whats in there
mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
@mysql_select_db($db_database); //connect to specific database
$query = "SELECT * FROM tblfilms WHERE FilmID = $id"; //define query
$result = mysql_query($query); //execute query and fill result with query's results
mysql_close();//close connection with MySQL database
//end grabbing movie info from database

//start filling local variables
$filmname = mysql_result($result,$i,"FilmName");
$filmfeatured = mysql_result($result,$i,"FilmFeatured");
$filmyear = mysql_result($result,$i,"FilmYear");
$filmgenre = mysql_result($result,$i,"FilmGenre");
$filmgenresecondary = mysql_result($result,$i,"FilmGenreSecondary");
$filmpicturelocation = mysql_result($result,$i,"FilmPictureLocation");
$filminfo = mysql_result($result,$i,"FilmInfo");
$filmrating = mysql_result($result,$i,"FilmRating");
$filmpopularity = mysql_result($result,$i,"FilmPopularity");
$filmnewpopularity = $filmpopularity + 1;
//end filling local variables

require_once( "config.php" ); //grab config file and do whats in there
mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
@mysql_select_db($db_database); //connect to specific database
$query = "UPDATE tblfilms SET FilmPopularity=$filmnewpopularity WHERE FilmID=$id"; //define query
$result = mysql_query($query); //execute query and fill result with query's results
mysql_close();//close connection with MySQL database
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"><!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title><!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /><!--Link to CSS style sheet-->
	
	<script type="text/javascript"><!--Start javascript to resize header-->

	var fitTextInBox_maxWidth = false;
	var fitTextInBox_maxHeight = false;
	var fitTextInBox_currentWidth = false;
	var fitTextInBox_currentBox = false;
	var fitTextInBox_currentTextObj = false;
	function fitTextInBox(boxID,maxHeight)
	{
		if(maxHeight)fitTextInBox_maxHeight=maxHeight; else fitTextInBox_maxHeight = 10000;
		var obj = document.getElementById(boxID);
		fitTextInBox_maxWidth = obj.offsetWidth;	
		fitTextInBox_currentBox = obj;
		fitTextInBox_currentTextObj = obj.getElementsByTagName('SPAN')[0];
		fitTextInBox_currentTextObj.style.fontSize = '1px';
		fitTextInBox_currentWidth = fitTextInBox_currentTextObj.offsetWidth;
		fitTextInBoxAutoFit();
		
	}	
	
	function fitTextInBoxAutoFit()
	{
		var tmpFontSize = fitTextInBox_currentTextObj.style.fontSize.replace('px','')/1;
		fitTextInBox_currentTextObj.style.fontSize = tmpFontSize + 1 + 'px';
		var tmpWidth = fitTextInBox_currentTextObj.offsetWidth;
		var tmpHeight = fitTextInBox_currentTextObj.offsetHeight;
		if(tmpWidth>=fitTextInBox_currentWidth && tmpWidth<fitTextInBox_maxWidth && tmpHeight<fitTextInBox_maxHeight && tmpFontSize<300){		
			fitTextInBox_currentWidth = fitTextInBox_currentTextObj.offsetWidth;	
			fitTextInBoxAutoFit();
		}else{
			fitTextInBox_currentTextObj.style.fontSize = fitTextInBox_currentTextObj.style.fontSize.replace('px','')/1 - 1 + 'px';
		}		
	}	
	</script><!--End javascript to resize header-->
</head>

<body>

<div id="wrapper"><!--Start Wrapper-->

	<script type="text/javascript">fitTextInBox('movieviewtitle', 200);</script>
	
	<div id="movieviewtitle"><!--Start Title Container-->
		<center><span>
			<?php
			echo "$filmname";//display film name
			?>
		</span></center>
	</div><!--End Title Container-->


	
	<div id="movieviewlogo"><!--Start Logo Container-->
		<img src="images/logo.png"/>
	</div><!--End Logo Container-->
	
	<div id="movieviewotherinfo"><!--Start Other Info Container-->
		<?php
		//Start displaying other info
		echo "<p><big>$filmyear<br>";
		echo "$filmgenre $filmgenresecondary<br><br>";
		//end displaying other info
		?>
	</div><!--End Other Info Container-->
	
	<br>
	
	<div id="menu"><!--Start Navigation Bar Container-->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!--End Navigation Bar Container-->

	<div id="content"><!--Start Content Container-->
	
		<div id= "column1"><!--Start Column1 Container-->
		
			<div id= "column1image"><!--Start Column1 Image Container-->
				<!--Start Feature/unfeature button code and displaying movie poster-->
				<?php
					
					if ( $username == 'admin' ) { //if user is logged on as admin
						if ( $filmfeatured == 1 ) { //and the film is featured
						$featuredunfeatured = "<form name='FeatureUnfeature' method='post'><input type='Submit' id='submit' name='submit' value='Un-Feature'></form>"; //display unfeature button
						$wanabefeatured = 0;
						} else { //and the film is not featured
						$featuredunfeatured = "<form name='FeatureUnfeature' method='post'><input type='Submit' id='submit' name='submit' value='Feature'></form>"; //display feature button
						$wanabefeatured = 1;
						}
					}
					
					if(isset($_POST['submit'])) { //if feature/unfeature button is clicked
						require_once( "config.php" ); //grab config file and do whats in there
						mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
						@mysql_select_db($db_database); //connect to specific database
						$query = "UPDATE tblfilms SET FilmFeatured='$wanabefeatured' WHERE FilmID='$id'"; //defines query
						$result = mysql_query($query); //executes query and fills result with query's results
						mysql_close();//close MySQL database connection
						echo "<meta http-equiv='refresh' content='0'>";//refresh page
					}
					echo "<img src='$filmpicturelocation' width='280' height='400' ><br><br>$featuredunfeatured";//displays movie poster
				?>
				<!--End Feature/unfeature button code and displaying movie poster-->
			</div><!--End Column1 Image Container-->
			
			<div id="column1text"><!--Start Column1 Text Container-->
					<?php
					echo "<u><h2>$filmname ($filmyear)</h2></u>";
					echo "<img src='images/ratings/$filmrating.png'><br><br>";
					echo "$filminfo";
					?>
			</div><!--End Column1 Text Container-->
			
		</div><!--End Column1 Container-->
		
		<div id="column2"><!--Start Column2 Container-->
			<?php
			$whereami = $pagenm * 3; //works out where to start pulling reviews from database (indicated by what page number on)
			require_once( "config.php" ); //grab config file and do whats in there
			mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
			@mysql_select_db($db_database); //connect to specific database
			$query = "SELECT * FROM tblreviews INNER JOIN tblusers ON tblreviews.UserID = tblusers.UserID WHERE FilmID =$id ORDER BY ReviewDate DESC LIMIT $whereami, 99"; //defining query
			$result = mysql_query($query); //run query and fill result
			$num = mysql_numrows($result); //number of records in result
			mysql_close(); //close database connect
					
			if ( $num < 3 ) {
				$limit = $num - 1;
			} else {
				$limit = 2;
			}
					
			for ( $i = 0; $i <= $limit; $i++ ) { //loop 1 to number of reviews (max 3)
				//start filling local variables
				$reviewreview = mysql_result($result, $i,"ReviewReview");
				$reviewdate = mysql_result($result, $i, "ReviewDate");
				$reviewusername = mysql_result($result, $i, "UserName");
				$reviewid = mysql_result($result, $i, "ReviewID");
				//end filling local variables
				
				//start outputting reviews
				echo "<h2><small>$reviewusername</small></h2>";
				echo "<p>$reviewreview</p>";
				//end outputting reviews
				
				if ( "$username" == "$reviewusername" ) {//if the user logged on is author
					$_SESSION['reviewreview'] = $reviewreview;
					$editing = 1;
					echo "<h3><a href='fillreviewbox.php'>Edit...</a>   $reviewdate</h3>";//display option to edit their review
				} elseif ( "$username" == "admin" ) {//if user logged on is admin
					$_SESSION['reviewid'] = $reviewid;
					echo "<h3><a href='deletereview.php'>Delete...</a>   $reviewdate</h3>";//display option to delete the review
				} else {
					echo "<h3>$reviewdate</h3>";//output review data
				}
			}
				
			$nextpagenm = $pagenm + 1;//calculating next page number
			$prevpagenm = $pagenm - 1;//calculating previous page number
			
			if ( $pagenm == 0 && $num < 3 ) {//if on page 1 and results less than 3
			//then dont do anything
			} elseif ( $pagenm > 0 ) {//or if not on page 1
				if ( $num < 3 ) {//and results less than three
					echo "<a href='movie.php?id=$id&page=$prevpagenm'>Prev</a>";//output "Prev" link
				} else {//or results more than three
					echo "<a href='movie.php?id=$id&page=$prevpagenm'>Prev</a>  -  <a href='movie.php?id=$id&page=$nextpagenm'>Next</a>";//output "Next" and "Prev" link
				}
			} else { //or if just on page one and results more than 3
				echo "<a href='movie.php?id=$id&page=$nextpagenm'>Next</a>";//output "Next" libk
			}
			
			if ( $num < 3 ) { //if results less than 3
				echo "<p><center>End of Reviews</center></p>"; //output message saying "End of Reviews"
			}
			
			if ( $editing != '1' ) { //if user is not editing
				unset($_SESSION['reviewreview']); //start clearing session variables
				unset($_SESSION['edit']); //end clearing session variables
			}

			$edit = $_SESSION['edit'];
			//start of displaying input form and submission button for reviews code
			echo "<form name='ReviewForm' method='post' action=''>";
			echo "<textarea rows='8' cols='75' maxlength='1000' id='review' name='review'>$edit</textarea><br>";
			echo "<input type='submit' name='save' value='Save' style='float:left;margin:0 5 0 0;'></form>";//<input type='hidden' name='clicked' value='1'>
			echo "<font size='2'>If you have already authored a review for this page, your previous review will be over-written.</font>";
			//end of displaying input form and submission button for reviews code
			
			require_once( "formvalidator.php" ); //do whats in formvalidator.php
			$show_form=true;
			$loggedin = $_SESSION['loggedin'];
			if (isset($_POST['save'])) { //if button "Save" is clicked
				if ( $loggedin == 1 ) { //and user is logged in
					//Setup Validations
					$validator = new FormValidator();
					$validator->addValidation("review","minlen=150","Review must be at least 150 characters long.");
					//End of Validations
					
					//begin declaring local variables
					$review = $_POST['review'];
					$userid = $_SESSION['userid'];
					//end declaring local variables
					
					//Start of search if user has already authored a review code
					require_once( "config.php" ); //grab config file and do whats in there
					mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
					@mysql_select_db($db_database); //connect to specific database
					$query = "SELECT * FROM tblreviews WHERE UserID='$userid' AND FilmID=$id"; //defining query
					$result = mysql_query($query);//Run query and fill result
					$num = mysql_numrows($result);//count number of records in result
					mysql_close();//close MySQL connection
					//End of search if user has already authored a review code
					
					if ( $num > 0 ) { //if user has already authored a review
						//begin updating existing review in database
						require_once( "config.php" ); //grab config file and do whats in there
						mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
						@mysql_select_db($db_database); //connect to specific database
						$query = "UPDATE tblreviews SET ReviewReview='$review', ReviewDate=NOW() WHERE FilmID=$id AND UserID='$userid'"; //defining query
						$result = mysql_query($query); //Run query and fill result
						mysql_close();//close MySQL connection
						//End updating existing review in database
						//Begin outputting message to show review updated
						echo "<h2>Previous Review Updated</h2>";
						echo "<meta http-equiv='refresh' content='2'>";
						//End outputting message to show review updated
					} else { //or if user hasnt already authored a review
						if($validator->ValidateForm()) {
							//validation sucsess
							require_once( "config.php" ); //grab config file and do whats in there
							mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
							@mysql_select_db($db_database); //connect to specific database
							$query = "INSERT INTO tblreviews (UserID, FilmID, ReviewReview) VALUES ('$userid', '$id', '$review')"; //defining query
							$result = mysql_query($query); //run query and fill result
							mysql_close(); //close MySQL connection
							//begin outputting notification to user than review added
							echo "<h2>Review Added</h2>";
							echo "<meta http-equiv='refresh' content='1'>";
							//end outputting notification to user than review added
						} else {
							//Unsucsessful validation
							echo "<B>Validation Errors:</B>";
							//Start Clearing Post Variables
							$_POST['FullName'] == "";
							$_POST['Email'] == "";
							$_POST['Username'] == "";
							$_POST['Password'] == "";
							$_POST['ConfirmPassword'] == "";
							//Finish Clearing Post Variables
							$error_hash = $validator->GetErrors();
							foreach($error_hash as $inpname => $inp_err) {
								echo "<p>$inp_err</p>\n";
							}        
						}
					}
					} else {//or if user not logged on
					echo "<p>You are not currently logged in. To register or login please click <a href='login.php'>here.</a>";//Notify user that they are currently not logged on so they cant add a review.
					}
				}
			?>
		</div><!--End Column2 Container-->
	
	</div><!--End Content Container-->
	
	<div class="clearfix"></div><!--Clear fix used to fix footer-->
	<br>
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to footer.php and do whats in there (display footer)
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->
</body>

</html>