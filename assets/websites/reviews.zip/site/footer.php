<?php
$username = $_SESSION['username'];//fill local variable

if ( $username == "" ) { //if username = 0 (ie if user is not logged in) 
	echo "<p>You are not logged in. Please click <a href='profile.php'>here</a> if you wish to log in.</p>"; //notifys user they are not logged in and gives them the option to log in
} elseif ( $username == "admin" ) { //if user is logged in as an admin
	echo "<p>Hello $username. Click <a href='admin.php'>here</a> to access the administrator control panel. If this is not your account please <a href='logout.php'>logout.</a></p>"; //notifys user they are logged in as admin and gives opportunity to use admin CP or logout
} else { //or if they are just logged in usually
	echo "<p>Hello $username. If this is not your account please <a href='logout.php'>logout.</a></p>"; //Greet user and give them option to log out
}
?>