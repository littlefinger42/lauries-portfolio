<?php
Session_start();//start PHP session
$_SESSION['whatpage'] = "films"; //Storing what page currently on (for navbar highlighting)
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"> <!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title> <!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /> <!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" /><!--Logo image itself with width and height definers-->
		<center>
	</div><!-- End Logo Container -->

	<div id="menu"><!-- Start Navigation bar Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Navigation bar Container -->

	<div id="featured"><!-- Start Featured Container -->
		<ul>
			<?php
				require_once( "listfeatured.php" );//do whats in listfeatured.php
			?>
		</ul>
	</div><!-- End Featured Container -->
	
	<div id="content"><!-- Start Content Container -->

		<br>
		<div id='column2'><!-- Start Column2 Container -->
		<!-- Start displaying search buttons -->
		<a href='listed.php?display=1&page=0'><img src='images/btnjustadded.png'></a>
		<a href='listed.php?display=2&page=0'><img src='images/btnfeatured.png'></a>
		<a href='listed.php?display=3&page=0'><img src='images/btnpopular.png'></a><br><br>
		<!-- End displaying search buttons -->
		</div><!-- End Column2 Container -->
		
		<div id='column1'><!-- Start Column1 Container -->
			<fieldset>
			<legend>Search</legend>
				<form action='' method='POST'>
					Search: <input type='text' name='searchvalue'> <!-- Search Label and Input Field -->
					<br><br>
					Genre: <!-- Genre Label -->
					<select name='filmgenre'><!-- Start Genre Input Field -->
						<option value="">-</option>
						<option value="Action">Action</option>
						<option value="Adventure">Adventure</option>
						<option value="Anime">Anime</option>
						<option value="Biography">Biography</option>
						<option value="Bollywood">Bollywood</option>
						<option value="Comedy">Comedy</option>
						<option value="Crime">Crime</option>
						<option value="Documentary">Documentary</option>
						<option value="Drama">Drama</option>
						<option value="Family">Family</option>
						<option value="Horror">Horror</option>
						<option value="Musical">Musical</option>
						<option value="History">History</option>
						<option value="Romance">Romance</option>
						<option value="Sci-Fi">Sci-Fi</option>
						<option value="Fantasy">Fantasy</option>
						<option value="Sport">Sport</option>
						<option value="Thriller">Thriller</option>
						<option value="War">War</option>
						<option value="Western">Western</option>
					</select><!-- End Genre Input Field -->
					<br><br>
					Year: <!-- Year Label -->
					<select name='filmyear'><!-- Start Year Input field -->
						<option value="">-</option>
						<?php
						for( $n = 1900; $n <= 2019; $n++) {
							echo "<option value='$n'>$n</option>";
						}
						?>
					</select><!-- End Year Input field -->
					<br><br>
					<input type='submit' value='Submit' name='Search'><!-- Search submission button -->
				</form>
			</fieldset>
		</div>
		<?php   
			if(isset($_POST['Search'])) {//if search button clicked
				//begin fillling local variables
				$searchvalue = $_POST['searchvalue'];
				$genre = $_POST['filmgenre'];
				$year = $_POST['filmyear'];
				//end fillling local variables
				echo("<meta http-equiv='refresh' content='0;url=listed.php?searchvalue=$searchvalue&genre=$genre&year=$year&page=0'>"); //redirect user to the appropiate listed.php page
			}
		?>	

	</div><!-- End Content Container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to footer.php and do whats in there (display footer)
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->
</body>

</html>