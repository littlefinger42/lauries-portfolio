<?php
Session_start(); //starting PHP session
$_SESSION['whatpage'] = "admin"; //Storing what page currently on (for navbar highlighting)
$username = $_SESSION['username']; //localising username variable for easy manipulation
if ( $username!="admin" ) { //checking the user is administrator
	exit("<center><img src='images/no.png'><br>This is an administrator only page. Click <a href='index.php'>here</a> to be redirected back to the homepage.</center>");
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"><!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title><!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /><!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" /><!--Logo image itself with width and height definers-->
		<center>
	</div><!-- End Logo Container -->

	<div id="menu"><!-- Start Navigation bar Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Navigation bar Container -->

	<div id="content"><!-- Start Content Container -->
		<?php
		if(isset($_POST['submitnews'])) {//if news submission button is clicked
			//start filling local variables
			$newsname = $_POST['newsname'];
			$newsinfo = $_POST['newsinfo'];
			//finish filling local variables
			
			require_once( "config.php" ); //grab config file and do whats in there
			mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
			@mysql_select_db($db_database); //connect to specific database
			$query = "INSERT INTO tblnews (NewsName, NewsNews) VALUES ('$newsname', '$newsinfo')"; //Defining Query
			$result = mysql_query($query); //Run query and fill result
			mysql_close();//close mysql connection
			
			echo "<B>News Added</B><br><p><a href='admin.php'>Add more</a></p>";//notify user that news has been added
			
			//start clearing variables
			unset ($_POST['newsname']);
			unset ($_POST['newsinfo']);
			//finish clearing variables
		}
		
		if(isset($_POST['submitfilm'])) {//if film submission button is clicked
			//start filling local variables
			$filmtitle = $_POST['filmtitle'];
			$filminfo = $_POST['filminfo'];
			$filmgenre1 = $_POST['filmgenre1'];
			$filmgenre2 = $_POST['filmgenre2'];
			$filmyear = $_POST['filmyear'];
			$filmagerating = $_POST['filmagerating'];
			$filmimageurl = $_POST['filmimageurl'];
			//finish filling local variables
			
			require_once( "config.php" ); //grab config file and do whats in there
			mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
			@mysql_select_db($db_database); //connect to specific database
			$query = "SELECT * FROM tblfilms WHERE FilmName='$filmtitle'"; //Define query
			$result = mysql_query($query); //Run query and fill result with results
			$num = mysql_numrows($result); //calculate number of records found
			mysql_close(); //close mysql connection
			
			if ( $num > 0 ) { //if film exists
				$filmid = mysql_result($result, $n, "FilmID");
				echo "Film already exists on database. For the film's link click <a href='movie.php?id=$filmid'>here.</a><br>";//notify user and provide link to the existing movie.php page
			} else { //if film does not exist
				require_once( "config.php" ); //grab config file and do whats in there
				mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
				@mysql_select_db($db_database); //connect to specific database
				$query = "INSERT INTO tblfilms (FilmName, FilmGenre, FilmGenreSecondary, FilmYear, FilmRating, FilmInfo, FilmPictureLocation) VALUES ('$filmtitle', '$filmgenre1', '$filmgenre2', '$filmyear', '$filmagerating', '$filminfo', '$filmimageurl')"; //defining query
				$result = mysql_query($query); //run query and fill result with results from query
				mysql_close(); //close mysql connection
				echo "<B>Film Added</B><br><p><a href='admin.php'>Add more</a></p>"; //notify user of addition of film
			}
		}

		?>
		
		<fieldset>
		<legend>Administrator Control Panel</legend><!--Displays Legend-->
		<form name='NewsAddition' method='POST' action='' accept-charset='UTF-8'><!--Start News Addition Form-->
		<table cellspacing='0' cellpadding='5' align="left">
			<td>
				<table cellspacing='2' cellpadding='2' border='0'>
					<tr>
						<td align='right' class='normal_field'>News Name</td><!--News Name Label-->
						<td class='NewsName'>
							<input type='text' maxlength="30" name='newsname' size='41' required><!--News Name Input-->
						</td>
					</tr>
					<tr>
						<td align='right' class='normal_field'>News Info</td><!--News Info Label-->
						<td class='NewsInfo'>
							<textarea rows='8' cols='30' maxlength='1000' id='newsinfo' name='newsinfo' required></textarea><!--News Info Input-->
						</td>
					</tr>
					<tr>
						<td colspan='2' align='center'>
							<input type='submit' name='submitnews' value='Submit News'><!--News Submission button-->
						</td>
					</tr>
				</table>
			</td>
		</table>
		</form><!--End News Addition Form-->
		<form name='FilmAddition' method='POST' action='' accept-charset='UTF-8'><!--Start Film Addition Form-->
		<table cellspacing='0' cellpadding='5' align="centre">
			<td>
				<table cellspacing='2' cellpadding='2' border='0'>
					<tr>
						<td align='right' class='normal_field'>Film Title</td><!-- Film Title Label -->
						<td class='FilmTitle'>
							<input type='text' maxlength='100' name='filmtitle' size='41' required><!-- Film Title Input -->
						</td>
					</tr>
					<tr>
						<td align='right' class='normal_field'>Film Info</td><!-- Film Info Label -->
						<td class='FilmInfo'>
							<textarea rows='8' cols='30' maxlength='500' id='filminfo' name='filminfo' required></textarea><!-- Film Info Input -->
						</td>
					</tr>
					<tr>
						<td align='right' class='normal_field'>Film Genre 1</td><!-- Film Genre 1 Label -->
						<td class='FilmGenre1'>
							<select name='filmgenre1' required><!-- Film Genre 1 Input START -->
								<option value="Action">Action</option>
								<option value="Adventure">Adventure</option>
								<option value="Anime">Anime</option>
								<option value="Biography">Biography</option>
								<option value="Bollywood">Bollywood</option>
								<option value="Comedy">Comedy</option>
								<option value="Crime">Crime</option>
								<option value="Documentary">Documentary</option>
								<option value="Drama">Drama</option>
								<option value="Family">Family</option>
								<option value="Horror">Horror</option>
								<option value="Musical">Musical</option>
								<option value="History">History</option>
								<option value="Romance">Romance</option>
								<option value="Sci-Fi">Sci-Fi</option>
								<option value="Fantasy">Fantasy</option>
								<option value="Sport">Sport</option>
								<option value="Thriller">Thriller</option>
								<option value="War">War</option>
								<option value="Western">Western</option>
							</select><!-- Film Genre 1 Input END -->
						</td>
					</tr>
					<tr>
						<td align='right' class='normal_field'>Film Genre 2</td><!-- Film Genre 2 Label -->
						<td class='FilmGenre2'>
							<select name='filmgenre2' required><!-- Film Genre 2 Input START -->
								<option value="Action">Action</option>
								<option value="Adventure">Adventure</option>
								<option value="Anime">Anime</option>
								<option value="Biography">Biography</option>
								<option value="Bollywood">Bollywood</option>
								<option value="Comedy">Comedy</option>
								<option value="Crime">Crime</option>
								<option value="Documentary">Documentary</option>
								<option value="Drama">Drama</option>
								<option value="Family">Family</option>
								<option value="Horror">Horror</option>
								<option value="Musical">Musical</option>
								<option value="History">History</option>
								<option value="Romance">Romance</option>
								<option value="Sci-Fi">Sci-Fi</option>
								<option value="Fantasy">Fantasy</option>
								<option value="Sport">Sport</option>
								<option value="Thriller">Thriller</option>
								<option value="War">War</option>
								<option value="Western">Western</option>
							</select><!-- Film Genre 2 Input END -->
						</td>
					</tr>
					<tr>
						<td align='right' class='normal_field'>Film Year</td><!-- Film Year Label -->
						<td class='FilmYear'>
							<select name='filmyear' required><!-- Film Year Input START -->
								<option value="">-</option>
								<?php
								for($n=1900;$n<=2019;$n++) {
									echo "<option value='$n'>$n</option>";
								}
								?>
							</select><!-- Film Year Input END -->
						</td>
					</tr>
					<tr>
						<td align='left' class='normal_field'>Film Age Rating</td><!-- Film Rating Label -->
						<td class='FilmAgeRating'>
							<select name='filmagerating' required><!-- Film Rating Input START -->
								<option value="U">U</option>
								<option value="PG">PG</option>
								<option value="12">12</option>
								<option value="15">15</option>
								<option value="15">18</option>
							</select> <!-- Film Rating Input END -->
						</td>
					</tr>
					<tr>
					   <td align='right' class='normal_field'>Film Image URL</td><!-- Film ImageURL Label -->
					   <td class='FilmImageURL'>
							<input type='text' name='filmimageurl' size='41' required><!-- Film ImageURL Input -->
					   </td>
					</tr>
					<tr>
						<td colspan='2' align='center'>
							<input type='submit' name='submitfilm' value='Submit Film'><!-- Film Submission Button -->
						</td>
					</tr>
				</table>
			</td>
		</table>
		</form>
		<table cellspacing='0' cellpadding='5' align="right">
			<td>
				Click <a href = "http://moodle.bourne-grammar.lincs.sch.uk/phpmyadmin321" target="_blank">here</a> if you wish to edit the MySQL database directly using PHPmyAdmin<!-- Displaying link to PHPmyAdmin to user -->
			</td>
		</table>
		</fieldset>
	</div><!-- End Content Container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to footer.php and do whats in there (display footer)
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->
</body>

</html>