<?php
Session_start(); //starts php session

//Start filling local variables
$reviewid = $_SESSION['reviewid'];
$filmid = $_SESSION['id'];
//end filling local variables

require_once( "config.php" ); //grab config file and do whats in there
mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
@mysql_select_db($db_database); //connect to specific database
mysql_query("DELETE FROM tblreviews WHERE ReviewID='$reviewid'"); //query from database
mysql_close(); //close MySQL connection
echo "<meta http-equiv='refresh' content='0;movie.php?id=$filmid'>" //redirect user back to movie page
?>
