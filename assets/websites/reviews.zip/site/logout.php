<?php
session_start();//start PHP session
//start clearing session data
session_unset();/
session_destroy();
session_write_close();
setcookie(session_name(),'',0,'/');
session_regenerate_id(true);
//end clearing session data
echo "<meta http-equiv='Refresh' content=0;URL=login.php>"; //redirect user back to login.php
?>
