<?php
Session_start();//starts PHP session
$_SESSION['whatpage'] = "login"; //Storing what page currently on (for navbar highlighting)

if (isset($_POST['submit'])) { //if submit button is clicked then
	
	$username = $_POST['username'];
	
	//start finding user account
	require_once( "config.php" ); //grab config file and do whats in there
	mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
	@mysql_select_db($db_database); //connect to specific database
	$query = "SELECT * FROM tblusers WHERE username='$username';"; //Defining query
	$result = mysql_query($query); //Run query and fill result
	mysql_close();//close mySQL connection
	//end finding user account
	$recordcount = mysql_numrows($result); //count records in result

	if ( $recordcount == 1 ) { //if user found
	//begin splitting record into local variables
	$password = mysql_result($result,0,"UserPass"); 
	$email = mysql_result($result,0,"UserEmail"); 
	$fullname = mysql_result($result,0,"UserFullName"); 
	$userid = mysql_result($result,0,"UserID"); 
	//end splitting record into local variables
		if ( $_POST['password'] == $password ) { //if password is correct
			//begin filling session variables
			$_SESSION['loggedin'] = 1;
			$_SESSION['username'] = $username;
			$_SESSION['userid'] = $userid;
			$_SESSION['fullname'] = $fullname;
			$_SESSION['email'] = $email;
			$_SESSION['password'] = $password;
			//end filling session variables
			$loggedin=$_SESSION['loggedin'];
			$badlogin = 0;
		} else { //if password is incorrect
			$badlogin = 1;
		}
	} else { //if user not found
		$badlogin = 2;
	}

}
 
if ( $_SESSION['loggedin']==0 && $badlogin==1 ) {
	echo "<meta http-equiv='Refresh' content=0;URL=login.php?badlogin=1>";//redirect to badlogin 1
} elseif ( $_SESSION['loggedin']==0 && $badlogin==2 ) {
	echo "<meta http-equiv='Refresh' content=0;URL=login.php?badlogin=2>";//redirect to badlogin 2
} elseif ( $_SESSION['loggedin']==0 && $badlogin==0 ) {
	echo "<meta http-equiv='Refresh' content=0;URL=login.php>";//redirect back to login page
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"> <!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title> <!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /> <!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="header"><!-- Start Header Container -->
		<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" />  <!--Logo image itself with width and height definers-->
		<center>
		</div><!-- End Logo Container -->
	</div><!-- End Header Container -->

	<div id="menu"><!-- Start Navigation Bar Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Navigation Bar Container -->

	<div id="content"><!-- Start Content Container -->
		<?php
			$fullname = $_SESSION['fullname'];
			echo "<h2>Profile:</h2>";//output title "Profile"
			echo "Hello $fullname.<br>";//Greet user
			echo "<br><a href=logout.php>Logout...</a>";//give user the option to logout
		?>
	</div><!-- End Content Container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to footer.php and do whats in there (display footer)
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->
</body>

</html>