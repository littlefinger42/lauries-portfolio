<?php
Session_start(); //starting PHP session
$_SESSION['whatpage'] = "login"; //Storing what page currently on (for navbar highlighting)
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"> <!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title> <!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /> <!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" />  <!--Logo image itself with width and height definers-->
		<center>
	</div><!-- End Logo Container -->


	<div id="menu"><!-- Start Menu Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Menu Container -->

	<div id="content"><!-- Start Content Container -->

		<?php
		require_once "formvalidator.php";//do whats in formvalidator.php
		$show_form=true;

		if(isset($_POST['Submit']))//if submit button is clicked
		{
			//Setup Validations
			$validator = new FormValidator();
			$validator->addValidation("FullName","alpha_s","Name must contain only letters and spaces");
			$validator->addValidation("Email","email","The input for Email should be a valid email.");
			$validator->addValidation("Password","minlen=6","Password must be over 6 characters long");
			$validator->addValidation("Username","alnum_s","Username may only contain alphabetically, numerical and space characters.");
			//Now, validate the form
			
			//begin declaring local variables
			$username = $_POST['Username'];
			$password = $_POST['Password'];
			$email = $_POST['Email'];
			$fullname = $_POST['FullName'];
			//end declaring local variables
			
			//begin checking if username or email exist on database
			require_once( "config.php" ); //grab config file and do whats in there
			mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
			@mysql_select_db($db_database); //connect to specific database
			$query = "SELECT * FROM tblusers WHERE UserName='$username' OR UserEmail='$email'"; //defining query
			$result = mysql_query($query); //execute query and fill result
			$num = mysql_numrows($result); //count records in result
			mysql_close(); //close connection with MySQL database
			//end checking if username or email exist on database
			
			if ( $num > 0 ) { //if username or email already on database
			echo "Username or Email address is already on the user database. Please use a different username or email address. If you already have an account, please login <a href='profile.php'>here.</a><br>";
			} else { //if username or email isnt already on database
				if($_POST['Password']==$_POST['ConfirmPassword']) { //if password field matches confirm password field
					if($validator->ValidateForm()) {
						//Validation success.
						//begin inserting new user into database
						require_once( "config.php" ); //grab config file and do whats in there
						mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
						@mysql_select_db($db_database); //connect to specific database
						$query = "INSERT INTO tblusers (UserName, UserPass, UserEmail, UserFullName) VALUES ('$username', '$password', '$email', '$fullname')"; //defining query
						$result = mysql_query($query); //execute query and fill result
						mysql_close(); //close connection with MySQL database
						echo "<h2>User successfully added. Click <a href='profile.php'>here</a> to be redirected to the login page to start using your new account!</h2>";//notifying the user that their account has been created.
						$show_form=false;
						//end inserting new user into database
					} else {
						//Unsucsessful validation
						echo "<B>Validation Errors:</B>";
						//Start Clearing Post Variables
						$_POST['FullName'] == "";
						$_POST['Email'] == "";
						$_POST['Username'] == "";
						$_POST['Password'] == "";
						$_POST['ConfirmPassword'] == "";
						//Finish Clearing Post Variables
						$error_hash = $validator->GetErrors();
						foreach($error_hash as $inpname => $inp_err)
						{
							echo "<p>$inp_err</p>\n";
						}        
					}
				} else {
					echo "<B>Passwords do not match.</B><br>";
				}
			}
		}

		if( true == $show_form ) {
		?>
		<fieldset>
		<legend>Register</legend>
		<form name='Registration' method='POST' action='' accept-charset='UTF-8'>
		<table cellspacing='0' cellpadding='10' border='0' bordercolor='#000000'>
			  <td>
				 <table cellspacing='2' cellpadding='2' border='0'>
					<tr>
					   <td align='right' class='normal_field'>Full Name</td><!-- Full Name Label -->
					   <td class='FullName'>
						  <input type='text' name='FullName' size='20' maxlength='30' required><!-- Full Name Input -->
					   </td>
					</tr>
					<tr>
					   <td align='right' class='normal_field'>Email</td><!-- Email Label -->
					   <td class='Email'>
						  <input type='text' name='Email' size='20' required><!-- Email Input -->
					   </td>
					</tr>
					<tr>
					   <td align='right' class='normal_field'>Username</td><!-- Username Label -->
					   <td class='Username'>
						  <input type='text' name='Username' size='20' maxlength='15' required><!-- Username Input -->
					   </td>
					</tr>
					<tr>
					   <td align='right' class='normal_field'>Password</td><!-- Password Label -->
					   <td class='Password'>
						  <input type='password' name='Password' size='20' maxlength='15' required><!-- Password Input -->
					   </td>
					</tr>
					<tr>
					   <td align='right' class='normal_field'>Confirm Password</td><!-- Confirm Password Label -->
					   <td class='ConfirmPassword'>
						  <input type='password' name='ConfirmPassword' size='20' maxlength='15' required><!-- Confirm Password Input -->
					   </td>
					</tr>
					<tr>
					<tr>
					   <td colspan='2' align='center'>
						  <input type='submit' name='Submit' value='Submit'><!-- Submit button -->
					   </td>
					</tr>
				 </table>
			  </td>
		   </tr>
		</table>
		</form>
		</fieldset>

		<?PHP
		}
		?>
		
	</div><!-- End Content Container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once("footer.php");
		?>
	</div><!-- End footer Container -->
	
</div><!-- End Wrapper -->

</body>

</html>