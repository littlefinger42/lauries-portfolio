<?php
Session_start(); //start PHP session
$_SESSION['whatpage'] = "login"; //stores session variable of what page the user is currently on. This is used for the header.
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html> 

<head>
	<LINK REL="SHORTCUT ICON" HREF="favicon.ico" type="image/x-icon"> <!--Displays webpage icon-->
	<META content="IE=edge" http-equiv="X-UA-Compatible"> 
	<META content="text/html; charset=UTF-8" http-equiv="content-type">
	<title>Movie Reviews - The Daily Tribune</title> <!--Define title of the webpage-->
	<link rel="stylesheet" type="text/css" href="css/style.css" /> <!--Link to CSS style sheet-->
</head>

<body>
<div id="wrapper"><!-- Start Wrapper -->

	<div id="homepagelogo"><!-- Start Logo Container -->
		<center>
			<img src="images/homepageheader.jpg" width="1143" height="163" alt="" /><!--Logo image itself with width and height definers-->
		<center>
	</div><!-- End Logo Container -->

	<div id="menu"><!-- Start Navigation bar Container -->
		<ul>
			<?php
			require_once( "navbar.php" ); //link to the navigation bar display code. This is located in the navbar.php.
			?>
		</ul>
	</div><!-- End Navigation bar Container -->

	<div id="content"><!-- Start Content Container -->

		<?php

			$badlogin = $_GET['badlogin'];// 1 = incorrect pass 2 = incorrect user 0 = havent attempted yet

			if ( $badlogin == 1 ) { //if password is incorrect
				echo '<h2>Login:</h2>';//display login title
				echo "Incorrect Password. Please try again.<br><br>"; //display message telling user incorrect password
				//start displaying login form
				echo '<form name=Input method=post action=profile.php>';
				echo 'Username: <input type="text" title="Please Enter Your Username" id="username" name="username"/><br>';
				echo 'Password: <input type="password" title="Please Enter Your Password" id="password" name="password"/><br>';
				echo '<input type=submit name=submit value=Login></form>';
				//end displaying login form
			} elseif ( $badlogin == 2 ) { //if username is incorrect
				echo '<h2>Login:</h2><br>';//display login title
				echo "Your username has not been recognized by our database. Please try again.<br><br>"; //display message telling user that the username has not been recongnized by database
				//start displaying login form
				echo '<form name=Input method=post action=profile.php>';
				echo 'Username: <input type="text" title="Please Enter Your Username" id="username" name="username"/><br>';
				echo 'Password: <input type="password" title="Please Enter Your Password" id="password" name="password"/><br>';
				echo '<input type=submit name=submit value=Login></form>';
				//end displaying login form
			} else { //if user has not attempted yet
				echo '<h2>Login:</h2><br>'; //display login title
				//start displaying login form
				echo '<form name=Input method=post action=profile.php>';
				echo 'Username: <input type="text" title="Please Enter Your Username" id="username" name="username"/><br>';
				echo 'Password: <input type="password" title="Please Enter Your Password" id="password" name="password"/><br>';
				echo '<input type=submit name=submit value=Login></form>';
				//end displaying login form
			}
			
		?>
		<br>
		Dont have an account? <a href="register.php">Register...</a> <!-- display link to register -->
		
	</div><!-- End Content Container -->
	
	<div id="footer-content"><!-- Start Footer Container -->
		<?php
			require_once( "footer.php" ); //link to footer.php and do whats in there (display footer)
		?>
	</div><!-- End Footer Container -->
	
</div><!-- End Wrapper -->

</body>

</html>