<?php
require_once( "config.php" ); //grab config file and do whats in there
mysql_connect($db_host, $db_user, $db_password); //connect to MySQL
@mysql_select_db($db_database); //connect to specific database
$query = "SELECT * FROM tblfilms WHERE FilmFeatured=1 ORDER BY FilmTimeAdded DESC LIMIT 0,10"; //defining query
$result = mysql_query($query); //Run query and fill result with results
$num = mysql_numrows($result); //calculate number of records found
mysql_close(); //close mysql connection
	
if ( $num > 5 ) {
	$count = 4;
} else {
	$count = $num - 1;
}
	
for ( $n == 1; $n <= $count; $n++ ) { //loop to the count of featured films (max 5)
	//start defining local variables
	$filmimage = mysql_result($result,$n,"FilmPictureLocation");
	$filmname = mysql_result($result,$n,"FilmName");
	$filmid = mysql_result($result, $n, "FilmID");
	$filmnameadapted = "$filmname;";
	//end defining local variables
	if ( strlen($filmnameadapted) > 25 ) { //if length of string is bigger than 25 characters...
		$position=25; // Characters allowed in $filmname
		$filmnameadapted = substr($filmname, 0, $position); //shrink string to characters allowed
		$filmnameadapted = "$filmnameadapted..."; //add "..."
	}
	echo "<li><a href = 'movie.php?id=$filmid'><img src=$filmimage alt='$filmname' title='$filmname' width=200 height=300><br>$filmnameadapted</a></li>";//display movie poster and shortened (if needed) name
}
?>