<?php
Session_start(); //start session
$_SESSION['edit'] = $_SESSION['reviewreview']; 
$filmid = $_SESSION['id'];
echo "<meta http-equiv='refresh' content='0;movie.php?id=$filmid'>" //redirect user back to movie.php page
?>
